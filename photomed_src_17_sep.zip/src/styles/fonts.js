const FONTS = {
    regular:'Poppins-Regular',
    medium:'Poppins-Medium',
    semiBold:'Poppins-SemiBold',
    extraBold:'Poppins-ExtraBold',
    bold:'Poppins-Bold',
}

export default FONTS