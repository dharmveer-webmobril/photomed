const COLORS = {
    primary: '#32327C',
    blackColor:'#000000',
    whiteColor:'#FFFFFF',
    Error: '#FF3B30',
    borderColor:'#424242',
    textColor:'#424242',
    greyBgColor:'#D6D8D7',
    placeHolderTxtColor:'#979797'
}

export default COLORS